**Refer https://github.com/appium/appium/tree/master/sample-code instead of this repository**

# sample-code

This repository contains sample applications which are used mostly by appium functional tests.
