package com.saucelabs.appium.page_object.widgets.html.extended;

import com.saucelabs.appium.page_object.widgets.html.annotated.AnnotatedHtmlMovies;
import org.openqa.selenium.WebElement;

public class ExtendedHtmlMovies extends AnnotatedHtmlMovies {
    protected ExtendedHtmlMovies(WebElement element) {
        super(element);
    }
}
