Python Pytest samples
==============

Tested on Python 3.5
pip install -r requirements.txt

# Run Syntax:
py.test test_android_simple.py -v

Output will be in the format:

test_android_simple.py::TestSimpleAndroid::test_find_elements PASSED
test_android_simple.py::TestSimpleAndroid::test_simple_actions PASSED

For more documentation please refer to http://doc.pytest.org/en/latest/