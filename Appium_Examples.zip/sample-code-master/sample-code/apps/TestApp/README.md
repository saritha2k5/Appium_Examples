## Repository
- https://github.com/appium/ios-test-app

## Copy from Simulator
```
$ cp path/to/ios-test-app/build path/to/sample-code/apps/TestApp/build
```

- `path/to` is an arbitrary path.
- `ios-test-app/build` is the result of `npm install` in `ios-test-app`
- `sample-code/apps/TestApp/build` is this direstory.
